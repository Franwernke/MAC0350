from .index import *
from .amostra import *
from .exame import *
from .paciente import * 
from .outros import *